// import el modelo
// import CustomerModel from "../models/CustomerModels.js";
const CustomerModel = require("../models/CustomerModels.js");

//METODOS CR

//Crear Registro
exports.createCustomer = async (req,res) => {
    try {
        await CustomerModel.create(req.body)
        res.status(200).send('Datos insertados correctamente')
    } catch (error) {
        res.json( {message: error.message})  
        console.log(error)
    }
}

//Mostrar registros

exports.getAll = async (req,res) =>{
    try {
       const customers = await CustomerModel.findAll()
       res.json(customers)
    } catch (error) {
        res.json( {message: error.message})
    }
}

