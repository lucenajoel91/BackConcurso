// import  express  from "express";
// import { createCustomer, getAll } from "../controllers/CustomerController.js";
const express = require("express");
const { createCustomer, getAll } = require("../controllers/CustomerController.js");

const router= express.Router();

router.get('/', getAll)
router.post('/',createCustomer)

// export default router
module.exports = router;
